#include <iostream>

using namespace std;

int main(){
    int N;
    cin >> N;
    char cur;
    int total = 0;

    for(int i = 0; i < N; i++){
        cin >> cur;
        switch(cur){
            case 'P':
                total += 2;
                break;
            case 'C':
                total += 2;
                break;
            case 'A':
                total += 1;
                break;
        }
    }

    cout << total << endl;

    return 0;
}