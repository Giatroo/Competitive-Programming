#include <iostream>

using namespace std;

int main()
{
	string s;
	cin >> s;
	int i, j, counter = 0;
	bool pal = true;
	char ac[50];

	for (i = 0; i < s.size(); i++)
	{
		if (s[i] == 'a' || s[i] == 'e' || s[i] == 'i' || s[i] == 'o' || s[i] == 'u')
			ac[counter++] = s[i];
	}

	for(i = 0, j = counter-1; i < counter && pal; i++, j--){
	if(ac[i] != ac[j]) pal = false;
	}
	
	if(pal) cout << "S\n";
	else cout << "N\n";

	return 0;
}