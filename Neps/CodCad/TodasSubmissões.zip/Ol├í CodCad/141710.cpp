#include <iostream>

using namespace std;

int main(){
  cout << "Ola CodCad!" << endl;
  return 0;
}