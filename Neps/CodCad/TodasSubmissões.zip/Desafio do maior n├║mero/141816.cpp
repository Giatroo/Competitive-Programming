#include <iostream>

using namespace std;

int main()
{
	int n, max;
	cin >> n;
	max = n;
	while(n != 0)
	{
		cin >> n;
		if(n > max)
			max = n;
	}
	cout << max << endl;
	return 0;
}