#include <iostream>

using namespace std;

int main()
{
    int N;
    cin >> N;
    int bombas[51], vizinhas[51];
    
    for(int i = 0; i < N; i++)
    {
        cin >> bombas[i];
        vizinhas[i] = 0;
    }

    if(bombas[0]) vizinhas[0]++;
    if(N > 1 && bombas[1]) vizinhas[0]++;

    for(int i = 1; i < N-1; i++)
    {
        if(bombas[i-1]) vizinhas[i]++;
        if(bombas[i]) vizinhas[i]++;
        if(bombas[i+1]) vizinhas[i]++;
    }
    
    if(N > 1 && bombas[N-2]) vizinhas[N-1]++;
    if(N > 1 && bombas[N-1]) vizinhas[N-1]++;
    
    for(int i = 0; i < N; i++){
        cout << vizinhas[i] << endl;
    }

    return 0;
}

