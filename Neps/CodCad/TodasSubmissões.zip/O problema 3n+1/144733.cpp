#include <iostream>

using namespace std;

int counter = 0;

void f(int n)
{
	if(n == 1) return;
	counter++;
	if(n % 2 == 0) f(n/2);
	else f(3*n + 1);
}


int main()
{
	int n;
	cin >> n;
	f(n);
	cout << counter << endl;
	return 0;
}