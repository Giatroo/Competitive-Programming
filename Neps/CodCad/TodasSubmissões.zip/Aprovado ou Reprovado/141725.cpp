#include <iostream>

using namespace std;

int main(){
  double x, y;
  cin >> x >> y;
  double avg = (x+y)/2;
  if(avg >= 7.0)
    cout << "Aprovado\n";
  else if(avg >= 4.0)
    cout << "Recuperacao\n";
  else
    cout << "Reprovado\n";

  return 0;
}