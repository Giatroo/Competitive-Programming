#include <iostream>

using namespace std;

int main()
{
	int p, n;
	cin >> p >> n;
	for(int i = 0; i < n; i++)
	{
		int k;
		cin >> k;
		if(k > 0)
		{
			if(k+p > 100)
				p = 100;
			else
				p += k;
		}		
		else
		{
			if(k+p < 0)
				p = 0;
			else
				p += k;
		}
	}
	cout << p << endl;
	return 0;
}