#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	char c;
	double a, b;
	cin >> c >> a >> b;
	if(c == 'M')
	{
		cout << fixed << setprecision(2) << a*b << endl;
	}
	else if(c == 'D')
	{
		cout << fixed << setprecision(2) << a/b << endl;
	}
	return 0;
}