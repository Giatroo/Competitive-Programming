#include <iostream> 

using namespace std;

int main(){
	int n, temp, soma, somaMax;
	cin >> n;
	int m[n+1][n+1];
	for(int i = 0; i < n+1;  i++){
		m[i][n] = m[n][i] = 0;
	}
	
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			cin >> temp;
			m[i][j] = temp;
			m[n][j] += temp;
			m[i][n] += temp;		
		}
	}
	
	somaMax = m[0][n] + m[n][0] - 2*m[0][0];
	
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			soma = m[i][n] + m[n][j] - 2*m[i][j];
			if(soma > somaMax) somaMax = soma;		
		}
	}
	
	cout << somaMax << endl;
	
	/*for(int i = 0; i < n+1; i++){
		for(int j = 0; j < n+1; j++){
			cout << m[i][j] << " ";	
		}
		cout << endl;
	}*/
	
	
	
	return 0;
}