#include <iostream>

using namespace std;

int main(){
    int N;
    int P, Q;
    char C;

    cin >> N >> P >> C >> Q;
    
    if(C == '+'){
        if(P + Q > N){
            cout << "OVERFLOW\n";
        } else {
            cout << "OK\n";
        }
    } else if(C == '*'){
        if(P * Q > N){
            cout << "OVERFLOW\n";
        } else {
            cout << "OK\n";
        }
    }

    return 0;
}