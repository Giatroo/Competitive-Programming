#include <iostream>

using namespace std;

int main(){
  double A, B;
  cin >> A >> B;
  if(A <= B)
    cout << "Pedro\n";
  else
    cout << "Paulo\n";
  return 0;
}